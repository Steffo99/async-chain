from .decorators import method_deco as method
